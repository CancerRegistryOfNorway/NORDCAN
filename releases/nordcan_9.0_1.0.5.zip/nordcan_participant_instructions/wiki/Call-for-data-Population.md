# Call for data - Population

### File - type and name
The prepared file needs to be in a format that can be read into R.  
There are no rules for filename. Examples in instructions use the name **general_population_size_dataset**.  

### Data types
A = String/char format  
F = Number/integer format  
Size = maximum allowed size for the variable  
Example: A50 = String variable, allowing maximum 50 characters/numbers.

## Population file
| Variable name | Variable description | Format/Size | Coding |  
|---------------|-------------------------------------------------------------------------------------|-------------|---------------------------------------------------------------------------------------------|
| year | Year of population count | A4 | >1941<current year <br> 9999 | 
| sex | Sex of population | F1 | 1 = Male <br> 2 = Female <br> 3 = Other & unknown | 
| region | Country/region | F2 | See [Regions](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) | 
| agegroup | 5-year age group for the population | F2 | See [Age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) | 
| pop_endofyear | Population at the end of each year for the combination of sex, region and age-group | F7 |  |  
| pop_midyear | Population at mid-year for the combination of sex, region and age-group | F7 |  |  

## Population projections
For predictions in NORDCAN, population projections are needed. They can be obtained from the national statistics bureaus. All projections contains a high growth projection, a main projection and a low growth projection. We use the main (medium) projection in NORDCAN. 

Projections should have the same data format as the population file, but have 1-year age groups for each year and sex instead of 5-year age groups. 
NORDPRED uses 5 x 5-year periods for predictions, so 25 years of population predictions is ideal. It might be - if it is not possible to deliver 25 years - that the program can run on 20 years, just filling out '0' in the last period. Midyear population is the most important for the population projections. 

The agegroup column should start from 1 and have at least age groups 1-101, where age group 101 is for ages 100+.

The first year in this table should be the one after the last year in the population size table.

This table would look like something like this:

| sex| region| year| agegroup| pop_midyear| pop_endofyear|
|---:|------:|----:|--------:|-----------:|-------------:|
|   2|     35| 2040|       92|      2917.5|          2908|
|   2|     35| 2040|       93|      2562.5|          2565|
|   2|     35| 2040|       94|      2137.5|          2158|
|   2|     35| 2040|       95|      1640.0|          1746|
|   2|     35| 2040|       96|      1107.0|          1228|
|   2|     35| 2040|       97|       728.0|           762|
|   2|     35| 2040|       98|       459.5|           512|
|   2|     35| 2040|       99|       344.0|           291|
|   2|     35| 2040|      100|       229.0|           267|
|   2|     35| 2040|      101|       342.5|           335|


