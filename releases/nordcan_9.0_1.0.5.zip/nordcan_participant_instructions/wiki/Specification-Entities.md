# Entitites in NORDCAN
Entities are the cancer sites/groups of cancer sites used in NORDCAN. They are made using ICD10-codes. 

Entities are used both for incidence, prevalence, mortality and survival. Mortality data back in time is less detailed than incidence/prevalence/survival, due to the fact that mortality is coded in ICD6/ICD7/ICD8/ICD9 which are less detailed classifications than ICD10.

For incidence, prevalence and survival, ICD10-codes is set by IARCcrgCheckTools from ICDO3 topography and morphology. 

For mortality, ICD10-codes for earlier years (before ICD10 was used) is converted from ICD6-ICD9. 

## Changes between 8.2 and 9.0

(Dev note: this table was formed manually by pasting the result of `knitr::kable(data.table::fread("https://raw.githubusercontent.com/CancerRegistryOfNorway/NORDCAN/master/specifications/entity_8.2_vs_9.0.csv"))` here)
| entity|description_en                                                    |in_8.2 |in_9.0 |comment                                                                                                                 |
|------:|:-----------------------------------------------------------------|:------|:------|:-----------------------------------------------------------------------------------------------------------------------|
|     10|Lip                                                               |Yes    |Yes    |C00.5 removed                                                                                                           |
|     20|Oral Cavity                                                       |Yes    |Yes    |C00.5, C05.8, C05.9 added                                                                                               |
|     30|Salivary glands                                                   |Yes    |Yes    |                                                                                                                        |
|     40|Oropharynx                                                        |Yes    |Yes    |C05.8-9 removed, C14 added                                                                                              |
|     41|Nasopharynx                                                       |Yes    |Yes    |                                                                                                                        |
|     50|Hypopharynx                                                       |Yes    |Yes    |                                                                                                                        |
|     51|Pharynx, ill defined                                              |Yes    |No     |Entity removed in 9.0. Cases moved to 40                                                                                |
|     60|Oesophagus                                                        |Yes    |Yes    |                                                                                                                        |
|     70|Stomach                                                           |Yes    |Yes    |                                                                                                                        |
|     80|Small intestine                                                   |Yes    |Yes    |                                                                                                                        |
|     90|Colon                                                             |Yes    |Yes    |                                                                                                                        |
|    100|Rectum                                                            |Partly |Yes    |C21 removed                                                                                                             |
|    110|Liver                                                             |Yes    |Yes    |                                                                                                                        |
|    120|Gallbladder                                                       |Yes    |Yes    |                                                                                                                        |
|    130|Pancreas                                                          |Yes    |Yes    |                                                                                                                        |
|    140|Nasal Cavity, middle ear and sinuses                              |Yes    |Yes    |                                                                                                                        |
|    150|Larynx                                                            |Yes    |Yes    |                                                                                                                        |
|    160|Lung                                                              |Yes    |Yes    |                                                                                                                        |
|    170|Pleura                                                            |Yes    |Yes    |                                                                                                                        |
|    180|Breast                                                            |Yes    |Yes    |                                                                                                                        |
|    190|Cervix uteri                                                      |Yes    |Yes    |                                                                                                                        |
|    200|Corpus uteri                                                      |Yes    |Yes    |                                                                                                                        |
|    210|Uterus, other                                                     |Yes    |Yes    |                                                                                                                        |
|    220|Ovary and tubes                                                   |Yes    |Yes    |                                                                                                                        |
|    227|Vulva                                                             |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    228|Vagina                                                            |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    229|Other female genital organs                                       |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    230|Vulva, vagina and other female genital organs                     |Yes    |Yes    |                                                                                                                        |
|    240|Prostate                                                          |Yes    |Yes    |                                                                                                                        |
|    250|Testis                                                            |Yes    |Yes    |                                                                                                                        |
|    260|Penis and other male genital organs                               |Yes    |Yes    |                                                                                                                        |
|    270|Kidney                                                            |Yes    |Yes    |                                                                                                                        |
|    280|Bladder and urinary tract                                         |Yes    |Yes    |Same ICD10-codes in both versions, but also exclusion on morphology codes. Not clear how/if this was implemented in 8.2 |
|    290|Melanoma of skin                                                  |Yes    |Yes    |                                                                                                                        |
|    300|Skin, non-melanoma                                                |Yes    |Yes    |C46.0, C46.2-9 removed                                                                                                  |
|    310|Eye                                                               |Yes    |Yes    |                                                                                                                        |
|    315|Endocrine tumors of brain and CNS                                 |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    316|Meningeomas                                                       |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    317|Gliomas                                                           |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    318|Nerve sheet tumors                                                |No     |No     |Not used in neither NORDCAN 8.2 or 9.0. Might be included later                                                         |
|    319|Other brain and CNS                                               |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    320|Brain and CNS excluding endocrine tumors                          |Yes    |Yes    |C75.1-3, D35.2-4 and D44.3-5 removed                                                                                    |
|    321|Brain and CNS including endocrine tumors                          |No     |Yes    |New in NORDCAN 9.0, same as old entity code 320                                                                         |
|    330|Thyroid                                                           |Yes    |Yes    |                                                                                                                        |
|    340|Bone                                                              |Yes    |Yes    |                                                                                                                        |
|    350|Soft tissues                                                      |Yes    |Yes    |C46.1 removed                                                                                                           |
|    360|Non Hodgkin lymphomas                                             |Yes    |Yes    |C880 and C96 added                                                                                                      |
|    370|Hodgkin lymphomas                                                 |Yes    |Yes    |                                                                                                                        |
|    380|Multiple myelomas                                                 |Yes    |Yes    |                                                                                                                        |
|    390|Myelodysplastic syndromes                                         |Yes    |Yes    |                                                                                                                        |
|    392|Myeloproliferative diseases                                       |Yes    |Yes    |                                                                                                                        |
|    394|Other hematopoietic diseases                                      |Yes    |Yes    |C88.0 and 96 removed, C94-6 and D47.2 added                                                                             |
|    401|Acute lymphatic leukaemias                                        |Yes    |Yes    |                                                                                                                        |
|    402|Chronic lymphatic leukaemias                                      |Yes    |Yes    |                                                                                                                        |
|    403|Other and unspecified lymphatic leukaemias                        |Yes    |Yes    |                                                                                                                        |
|    404|Acute myeloid leukaemias                                          |Yes    |Yes    |C94.4-5 removed, C92.3-6 added                                                                                          |
|    405|Chronic myeloid leukaemias                                        |Yes    |Yes    |                                                                                                                        |
|    406|Other and unspecified myeloid leukaemia                           |Yes    |Yes    |C92.3-6 removed, C94.4 added                                                                                            |
|    407|Leukaemia, cell unspecified                                       |Yes    |Yes    |C91, C92, C93, C94 added (2-digit ICD10-codes), should not impact incidence. Might impact mortality                     |
|    410|Other specified cancers                                           |Partly |Yes    |C21, C46.0-1 added                                                                                                      |
|    420|Other and ill-defined cancers                                     |Yes    |Yes    |                                                                                                                        |
|    430|Malignant haematopoietic diseases                                 |Yes    |Yes    |D47.2 added                                                                                                             |
|    431|Non Hodgkin lymphoma NOS                                          |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    434|Classical Hodgkin lymphoma                                        |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    435|Chronic lymphocytic leukaemia/small lymphocytic lymphoma          |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    436|Immunoproliferative diseases                                      |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    437|Mantle cell/centrocytic                                           |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    438|Follicular B lymphoma                                             |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    439|Diffuse B lymphoma                                                |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    440|Burkitt's lymphoma                                                |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    441|Marginal zone lymphoma                                            |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    442|T lymphoma cutenaeous                                             |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    443|Other T cell lymphomas                                            |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    444|Lymphoblastic lymphoma/Acute (precursor cell) lymphatic leukaemia |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    445|Plasma cell neoplasms                                             |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    446|Mature B cell leukaemia                                           |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    448|Lymphatic leukaemia, NOS                                          |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    449|Leukaemia, NOS                                                    |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    450|Myeloid leukaemia, NOS                                            |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    451|Acute myeloid leukaemia                                           |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    452|Myeloproliferative neoplasms                                      |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    453|Myelodysplastic syndrome                                          |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    454|Myelodysplastic/myeloproliferative neoplasms NOS                  |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    455|Other and unscpecified lymphomas                                  |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    456|Other and unspecified leukaemias                                  |No     |Yes    |New in NORDCAN 9.0                                                                                                      |
|    510|Lip, oral cavity and pharynx                                      |Yes    |Yes    |                                                                                                                        |
|    520|Colorectal                                                        |Partly |Yes    |C21 removed                                                                                                             |
|    888|Basal cell carcinoma                                              |Yes    |Yes    |                                                                                                                        |
|    970|All sites but non-melanoma skin cancer, breast and prostate       |Yes    |Yes    |                                                                                                                        |
|    980|All sites                                                         |Yes    |Yes    |                                                                                                                        |
|    990|All sites but non-melanoma skin cancer                            |Yes    |Yes    |                                                                                                                        |
|    999|Not included in NORDCAN                                           |Yes    |Yes    |                                                                                                                        |
