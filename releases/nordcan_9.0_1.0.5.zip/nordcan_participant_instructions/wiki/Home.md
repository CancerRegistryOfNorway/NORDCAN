# Welcome to the NORDCAN wiki!

NORDCAN is a database of cancer statistics for the Nordic countries: Denmark, Finland, Iceland, Norway, Sweden, the Faroe Islands, and Greenland. It includes information on the number of new cancer cases (incidence), cancer mortality, the number of individuals living with a cancer diagnosis (prevalence), and cancer survival. The various statistical data are freely available in tables and figures for more than 50 cancer entities. The population-based data in NORDCAN are more recent than those available for most other countries in the world, and the database is updated each year.

You can find NORDCAN at [nordcan.iarc.fr](https://nordcan.iarc.fr/).

NORDCAN is the joint collaboration between [ANCR](https://www.ancr.nu/) and [IARC](https://www.iarc.fr/), funded to a large degree by the [NCU](http://ncu.nu/). 

## The NORDCAN data processing project
The NORDCAN data processing project contained in this repository is a joint collaboration on the development of R-scripts used by each cancer registry to take cancer data from raw data to aggregated and quality assured statistics that can be shown at the NORDCAN webpage. 

## Project group
**Developers**
* Joonas Miettinen ([Finnish Cancer Registry](https://cancerregistry.fi/))
* Sasha Pejicic ([Swedish Cancer Registry](https://www.socialstyrelsen.se/))
* Huidong Tian ([Cancer registry of Norway](https://www.kreftregisteret.no/))
* Bjarte Aagnes ([Cancer registry of Norway](https://www.kreftregisteret.no/))

**Data management and testing**
* Niklas Toorell ([Swedish Cancer Registry](https://www.socialstyrelsen.se/))
* Marnar Fríðheim Kristiansen (Faroe Islands Cancer Registry)
* Charlotte Wessel Skovlund ([Danish Cancer Society](https://www.cancer.dk/international/))
* Gerda Engholm ([Danish Cancer Society](https://www.cancer.dk/international/))
* Anna Skog ([Cancer registry of Norway](https://www.kreftregisteret.no/))

**Project management**
* Siri Larønningen ([Cancer registry of Norway](https://www.kreftregisteret.no/))