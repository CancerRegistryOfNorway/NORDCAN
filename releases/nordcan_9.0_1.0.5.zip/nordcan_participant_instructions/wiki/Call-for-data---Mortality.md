# Call for data - Mortality

The call for data for mortality includes cancer-specific mortality - not all cause mortality. 

### File - type and name
The prepared file needs to be in a format that can be read into R.  
There are no rules for filename. Examples in instructions use the name **unprocessed_cancer_death_count_dataset**. 

### Data types
A = String/char format  
F = Number/integer format  
Size = maximum allowed size for the variable  
Example: A50 = String variable, allowing maximum 50 characters/numbers.  

### ICD-codes
ICD-codes have a maximum length of 4. If a 5th digit exists in old ICD-codes, this needs to be removed, i.e. "14000" must be changed to "1400"  
Special characters in codes, like "-", "." or ";" also needs to be removed, i.e. "140-0" must be changed to "1400".  
A leading letter (most often "C" or "D") is allowed for ICD10. Only numbers are allowed for ICD6-ICD9.  

## Recommendations
Deaths with missing information on region should be included in the country total, that is: given the country code as regional code (see [Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions)).

# Data to be extracted:
| ﻿Variable name | Variable description | Format/Size | Coding |
|------------------|--------------------------------------------------------------------------------------|-------------|---------------------------------------|
| year | Year of death | A4 | >1941<current year <br> 9999 = Unknown |
| sex | Sex of population | F1 | 1 = Male <br> 2 = Female <br>3 = Other & unknown |
| region | Country/region | F2 | See [Regions](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) |
| agegroup | 5-year age group | F2 | See [Age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) |
| icd_code | Cause of Death | A4 | Valid code in ICD <br> 9999 |
| icd_version | ICD-version used in that record | F2 | 6 = ICD6 <br> 7 = ICD7 <br> 8 = ICD8 <br> 9 = ICD9 <br> 10 = ICD10 |
| cancer_death_count | Number of deaths for the combination of year of death, sex, region, agegroup and CoD | F4 |  |

## CoD-versions 
|             | ICD-6     | ICD-7     | ICD-8     | ICD-9     | ICD-10   | ICD-O-3        |
|-------------|-----------|-----------|-----------|-----------|----------|----------------|
|Denmark      | 1951-1957 | 1958-1968 | 1969-1993 |           | 1994 --> |                |
|Faroe Islands|           |           |           |           |          |                |
|Finland      |           |           | 1969-1988 | 1987-1995 | 1996 --> | 1953 --> (*)   |
|Greenland    |           |           |           |           |          |                |
|Iceland      |           | 1951-1970 | 1971-1980 | 1981-1995 | 1996 --> |                |
|Norway       | 1951-1957 | 1958-1968 | 1969-1985 | 1986-1995 | 1996 --> |                |
|Sweden       | 1952-1957 | 1958-1968 | 1969-1986 | 1987-1996 | 1997 --> |                |

(*) Finland computes death counts by cancer site in-house using cancer records which are coded in ICD-O-3;
  Statistics Finland offers similar data under varying coding schemas and their data starts substantially
  later

## Conversions between ICD6-9 and ICD10
The NORDCAN R-modules contain a conversion between ICD6-9 and ICD10, so this conversion is done automatically when running the program. 