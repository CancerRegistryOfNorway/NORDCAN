## NORDCAN risk assessment

In December 2020, the NORDCAN group did a risk assessment analysis to ensure confidentiality in tables and graphs in NORDCAN. The risk assessment is available [here.](https://github.com/CancerRegistryOfNorway/NORDCAN/blob/master/documents/NORDCAN%20risk%20assessment.pdf)

## Background information and practical advice

Background information for the risk assessment and some practical advice on protecting confidentiality in tables and graphs can be found [here.](https://github.com/CancerRegistryOfNorway/NORDCAN/blob/master/documents/NORDCAN%20-%20protecting%20confidentiality.pdf)