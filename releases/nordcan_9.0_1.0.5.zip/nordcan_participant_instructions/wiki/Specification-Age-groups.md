# Age groups used in NORDCAN

## Incidence/mortality/prevalence
| ﻿**Age group value** | **Age group description** |
|-------------------|-----------------------|
| 01                | 00-04                 |
| 02                | 05-09                 |
| 03                | 10-14                 |
| 04                | 15-19                 |
| 05                | 20-24                 |
| 06                | 25-29                 |
| 07                | 30-34                 |
| 08                | 35-39                 |
| 09                | 40-44                 |
| 10                | 45-49                 |
| 11                | 50-54                 |
| 12                | 55-59                 |
| 13                | 60-64                 |
| 14                | 65-69                 |
| 15                | 70-74                 |
| 16                | 75-79                 |
| 17                | 80-84                 |
| 18                | 85-89                 |
| 19                | Not used              |
| 20                | Not used              |
| 21                | 90+                   |

## Survival
|Value |Any site grouping <br>(agr_all_ages)|Bone, Hodgkin and testis <br>(agr_bone)|Other (agr_other) <br>All sites (agr_all_sites)|
|------|-----------------|------------------------|-------------|
|0     |0-89             |                        |             |
|      |                 |                        |             |
|1     |                 |0-29                    |0-29         |
|2     |                 |30-39                   |30-49        |
|3     |                 |40-49                   |50-69        |
|4     |                 |50-69                   |70-79        |
|5     |                 |70-89                   |80-89        |
|6     |                 |90+                     |90+          |