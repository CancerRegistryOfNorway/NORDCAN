# Output

The NORDCAN R/Stata creates the following output files: 

## Incidence
_nordcan_statistics_cancer_record_count_for_xxx_by_sex_entity_yoi_region_agegroup_

| ﻿**Variable name** | **Description**              |
|---------------|----------------------------------|
|yoi            |year of incidence                 |
|sex            |sex of the patient                |
|region         |[Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) for the incident cases |
|agegroup       |5-year [age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) for the incident cases |
|entity         |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the incident cases |
|cancer_record_count |number of cases in stratum |

## Prevalence
_nordcan_statistics_prevalent_patient_count_for_xxx_by_sex_entity_region_agegroup_observation_full_years_since_entry_

| ﻿**Variable name** | **Description**                      |
|---------------|----------------------------------|
| region        | [Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) for the prevalent cases   |       
| year_of_observation          | the end of each year given here is the point of observation          |       
| entity        | [Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the prevalent cases |       
| agegroup           | 5-year [age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) for the cases  |       
| sex         | sex of the patient    |       
| full_years_since_entry      | full years between the point of observation and time of entry         |       
| prevalent_patient_count      | number of prevalent cancer patients in stratum         |       

## Mortality
_nordcan_statistics_cancer_death_count_for_xxx_by_sex_entity_year_region_agegroup_

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|entity               |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the cancer death cases     |       
|sex                |sex of the patient            |       
|region             |[Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) for the cancer death cases  |    
|agegroup           |5-year [age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) |    
|year               |year of death                 |       
|cancer_death_count |number of cancer deaths in stratum       |       

## Population
_nordcan_population_size_for_xxx_by_sex_year_region_agegroup_

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|year               |year of population count      |       
|sex                |sex of population             |       
|agegroup           |5-year [age groups](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Age-groups) of the population|       
|region             |[Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) for the population |    
|pop_endofyear      |population count at end of year in stratum |     
|pop_midyear        |mid-year population count in stratum    |       


## Survival
_nordcan_statistics_survival_iccs_std_ns_for_xxx_by_sex_entity_period_5_

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|entity               |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the incident cases     | 
|entity_display_order |order of entities in GUI |
|entity_description_en |entity description |
|end |1-year or 5-year survival |
|cns | |
|locns | |
|upcns | |
|sex |sex of patient |
|period_5|startyear of 5-year diagnostic period |
|country |name of country |
|metadata |metdata for the survival file |

_nordcan_statistics_survival_iccs_std_ns_for_xxx_by_sex_entity_period_10_

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|entity               |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the incident cases     | 
|entity_display_order |order of entities in GUI |
|entity_description_en |entity description |
|end |1-year or 5-year survival |
|cns | |
|locns | |
|upcns | |
|sex |sex of patient |
|period_10|startyear of 10-year diagnostic period |
|country |name of country |
|metadata |metdata for the survival file |


## Incidence and mortality quality
_nordcan_statistics_incdience_quality_for_xxx_by_sex_entity_period_5_region_

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|sex               |sex of patients      | 
|period_5          |5-year period of diagnosis |
|region            |[Region](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Regions) of the incident cases |
|entity            |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the incident cases |
|cancer_record_count |number of cases in total in the original file |
|cancer_record_count_included |number of cases included in NORDCAN |
|percentage_included |percentage of total cases included in NORDCAN |
|percentage_mv |percentage of morphologically verified cases |
|percentage_dco |percentage cases verified through death certificate only |
|mi_ratio |mortality-to-incidence ratio |

## Survival quality
_nordcan_statistics_survival_quality_for_xxx_by_sex_entity_period_5

| ﻿**Variable name** | **Description**              |
|-------------------|------------------------------|
|sex               |sex of patients      | 
|period_5          |startyear of 5-year diagnostic period |
|entity            |[Entity](https://github.com/CancerRegistryOfNorway/NORDCAN/wiki/Specification-Entities) for the incident cases |
|cancer_record_count |number of cases in total in the original file |
|cancer_record_count_included |number of cases included in survival analysis NORDCAN |
|percentage_included |percentage of total cases included in survival analysis NORDCAN |
|percentage_excl_surv_age |percentage of cases excluded because patient was above 90 at time of diagnosis |
|percentage_excl_surv_dco |percentage of cases excluded because only source is death certificate |
|percentage_excl_surv_autopsy |percentage of cases excluded because cancer was found at autopsy |
|percentage_excl_surv_negativefou |percentage of cases excluded due to negative follow up |
|percentage_excl_surv_duplicate |percentage of cases excluded due to being duplicate records |
|percentage_not_reported_in_nordcan |total percentage of cases not included in NORDCAN |