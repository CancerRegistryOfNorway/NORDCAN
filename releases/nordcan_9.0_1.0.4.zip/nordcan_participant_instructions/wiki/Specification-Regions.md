# Regions used in NORDCAN

| **﻿Value** | **Description**        |
|-------|---------------------|
| **10**    | **Denmark**             |
| 11    | North Jutland       |
| 12    | Central Jutland     |
| 13    | Southern Denmark    |
| 14    | Greater Copenhagen  |
| 15    | Zealand             |
| **20**    | **Faroe Islands**       |
| **30**    | **Finland**             |
| 31    | Helsinki            |
| 32    | Kuopio              |
| 33    | Oulu                |
| 34    | Tampere             |
| 35    | Turku               |
| **40**    | **Iceland**             |
| 41    | Reykjavik-Reykjanes |
| 42    | Rural               |
| **50**    | **Norway**              |
| 51    | Central             |
| 52    | Northern            |
| 53    | Southeastern        |
| 54    | Western             |
| **60**    | **Sweden**              |
| 61    | Northern            |
| 62    | Stockholm-Gotland   |
| 63    | Southern            |
| 64    | Southeastern        |
| 65    | Uppsala-Örebro      |
| 66    | Western             |
| **80**    | **Greenland**           |
| **90**    | **Nordic countries**    |