# Call for data - Survival

## 1. The survival call for data uses _the same cancer case data as incidence and prevalence_. 
## 2. Life table file to prepare in each country:

A national population life table containing the conditional probability of SURVIVING the next year for each combination of values of the demographic variables; age, year and sex.

This can be obtained, or calculated, using data from national official statistics for each country. Alternatively, downloaded from a general source like the Human Mortality Database https://www.mortality.org/

### File - type and name
The prepared file needs to be in a format that can be read into R.  
There are no rules for filename. Examples in instructions use the name **national_population_life_table**.  

**Variable naming:**        
| Variable name  | Variable label/explanation |
| ------------- | ------------- |
| year | calendar year  |
| sex   | 1 = Male , 2 = Female |
| age  | age (at least years 0-90) |
| prob  | conditional probability for surviving one year |

Data Sorted by: year  sex  age

Observations uniquely identified by combinations of variables: year sex age

Example records for Norway:  
2018;2;0;.997833  
2018;2;1;.999895  
2018;2;2;.999966
