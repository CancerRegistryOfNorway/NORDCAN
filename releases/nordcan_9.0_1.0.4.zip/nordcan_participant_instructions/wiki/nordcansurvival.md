# nordcan 9.0 survival methods

**DRAFT DO NOT CITE**

## Estimation

Age-standardised relative survival was estimated using the Pohar Perme estimator. Age-standardization was performed by weighting individual observations (Brenner 2004, Rutherford et al (2020)) using external weights as defined below. National general population life-tables stratified by sex, year and age was used in calculation of expected survival. 

The Stata program stnet was used for calculations. 

## Age groups and weights

The adjusted International Cancer Survival Standards (ICSS) used are described in *Trends in the survival of patients diagnosed with cancer in the Nordic countries 1964–2003 followed up to the end of 2006. Material and methods.* 

1. ICSS 1  Young adults: 
    1. Testis, Hodgkin lymphoma: 0-29 (31), 30-39 (21), 40–49 (13), 50–69 (20), 70–89 (15)
    2. Acute leukemia: 0-29 (31), 30–49 (34), 50–69 (20), 70–79 (10), 80–89 (5)

2. ICSS 2  Little age dependency  

    1. Bone: 0-29 (7), 30-39 (13), 40–49 (16), 50–69 (41), 70–89 (23)
    2. Melanoma, cervix, brain, thyroid, soft tissue: 0–49 (36), 50–59 (19), 60–69 (22), 70–79 (16), 80–89 (7)

3. ICSS 3 Elderly

    1. Other sites and summary groups: 0–49 (12), 50–59 (17), 60–69 (27), 70–79 (29), 80–89 (15)
            
## Definition of follow-up

*Cohort approach* for all but last five-year period for which the *period approach* was used.

## Inclusion 

    1. Set of predefined groups of entities
    2. Patients are included with first case of each group to be analysed
    3. DCO cases are not included. 
    4. Patients 90 year or older was excluded
    5. Groups analysed if minimum 30 patients alive at start with minimum 3 in any one of the 5 age-groups used for weighting

## References: 

Stata stnet version version 1.0.8 2020-06-11

https://www.pauldickman.com/software/stnet/

Enzo Coviello, Karri Seppä, Paul W. Dickman, Arun Pokhrel, 2015.
Estimating net survival using a life-table approach,
The Stata Journal, StataCorp LP, vol. 15(1), pages 173-185.
https://doi.org/10.1177%2F1536867X1501500111

The age-standardisation method is described in the article

Mark J. Rutherford, Paul W.Dickman, EnzoCoviello, Paul C.Lambert, 2020.
Estimation of age-standardized net survival, even when age-specific data are sparse
https://doi.org/10.1016/j.canep.2020.101745

An illustration of the age-standardisation method is available at https://www.pauldickman.com/software/strs/age_standardised_net_survival/

Gerda Engholm, Mette Gislum, Freddie Bray & Timo Hakulinen (2010) Trends in the survival of patients diagnosed with cancer in the Nordic countries 1964–2003 followed up to the end of 2006. Material and methods, Acta Oncologica, 49:5, 545-560, https://doi.org/10.3109/02841861003739322

Hermann Brenner, Volker Arndt, Olaf Gefeller, Timo Hakulinen (2004) An alternative approach to age adjustment of cancer survival rates https://doi.org/10.1016/j.ejca.2004.07.007
	


