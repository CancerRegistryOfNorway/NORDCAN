# Content of nordcan maintainer summary
NORDCAN R/Stata provides the user with 5 files for quality control and checks.

## cancer_death_count_dataset.png
cancer_death_count_dataset.png is a graphic comparison of mortality data in the existing (published) version of NORDCAN and mortality data computed now. The existing version is always displayed as the baseline ('0').

## cancer_record_count_dataset.png
cancer_record_count_dataset.png is a graphic comparison of incidence data in the existing (published) version of NORDCAN and incidence data computed now. The existing version is always displayed as the baseline ('0').

## prevalent_patient_count_dataset.png
prevalent_patient_count_dataset.png is a graphic comparison of prevalence data in the existing (published) version of NORDCAN and prevalence data computed now. The existing version is always displayed as the baseline ('0').

## comparison_summary.csv
comparison_summary.csv contains information on the comparison between the existing and the new version of all datasets computed by NORDCAN R/Stata.

## session_info.txt
session_info.txt contains information on the run process and output of NORDCAN R/Stata, like system time at start, R-version, platform, OS etc.